import requests

url = "https://openrouter.ai/api/v1/chat/completions"

headers = {
    "Authorization": "Bearer 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",  # sua chave
    "Content-Type": "application/json",
    "HTTP-Referer": "http://localhost",             # 👈 obrigatório mesmo localmente
    "X-Title": "Moderador AI"
}

data = {
    "model": "openai/gpt-4o-mini",
    "messages": [
        {"role": "user", "content": "Olá, tudo bem? Responda com 'teste ok'."}
    ]
}

resp = requests.post(url, headers=headers, json=data)
print(resp.status_code)
print(resp.text)
